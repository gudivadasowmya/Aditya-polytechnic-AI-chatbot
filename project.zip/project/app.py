
from flask import Flask, request, jsonify, render_template
from pathlib import Path
import json
import random
import sqlite3
import joblib

# Create Flask application
app = Flask(__name__)

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "college_chat.db"

# Load trained AI model
model = joblib.load(BASE_DIR / "chatbot_model.pkl")

# Load questions and answers
with open(BASE_DIR / "intents.json", "r", encoding="utf-8") as file:
    intents = json.load(file)["intents"]

responses = {
    item["tag"]: item["responses"]
    for item in intents
}

# Create database
def init_db():
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_query TEXT,
                bot_reply TEXT,
                intent TEXT,
                confidence REAL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

init_db()

# Homepage
@app.route("/")
def home():
    return render_template("index.html")

# Chatbot API
@app.route("/chat", methods=["POST"])
def chat():
    data = request.get_json(silent=True) or {}
    message = str(data.get("message", "")).strip()

    if not message:
        return jsonify({"reply": "Please type a question."}), 400

    intent = None
    confidence = 0.0

    # Check exact questions first
    for item in intents:
        for pattern in item["patterns"]:
            if message.lower() == pattern.lower():
                intent = item["tag"]
                confidence = 1.0
                break

        if intent is not None:
            break

    # Use AI model for questions not exactly matched
    if intent is None:
        probabilities = model.predict_proba([message])[0]

        index = probabilities.argmax()
        confidence = float(probabilities[index])
        intent = model.classes_[index]

    # Reject questions with low confidence
    if confidence < 0.25:
        intent = "fallback"
        reply = (
            "Sorry, I could not understand your question. "
            "Please ask about admissions, fees, hostel, "
            "scholarships, branches, timings or placements."
        )
    else:
        reply = random.choice(responses[intent])

    # Store chat history
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute(
            """INSERT INTO logs
            (user_query, bot_reply, intent, confidence)
            VALUES (?, ?, ?, ?)""",
            (message, reply, intent, confidence)
        )

    return jsonify({
        "reply": reply,
        "intent": intent,
        "confidence": round(confidence * 100, 2)
    })

# Run application
if __name__ == "__main__":
    app.run(debug=True, port=5000)
